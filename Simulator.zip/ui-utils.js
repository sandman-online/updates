// Toast Benachrichtigungen
class Toast {
    static container = null;

    static init() {
        if (!this.container) {
            this.container = document.createElement('div');
            this.container.className = 'toast-container';
            document.body.appendChild(this.container);
        }
    }

    static show(message, type = 'info') {
        this.init();
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        this.container.appendChild(toast);

        // Toast nach Animation entfernen
        setTimeout(() => {
            toast.remove();
        }, 3000);
    }
}

// Modal Dialog
class ConfirmDialog {
    static async show(message, confirmText = 'Bestätigen', cancelText = 'Abbrechen', enableInput = false, defaultValue = '') {
        return new Promise((resolve) => {
            const modal = document.createElement('div');
            modal.className = 'modal-backdrop';
            modal.innerHTML = `
                <div class="modal-dialog">
                    <div class="modal-title">Bestätigung erforderlich</div>
                    <div class="modal-content">${message}</div>
                    ${enableInput ? `<input type="text" class="modal-input" value="${defaultValue}">` : ''}
                    <div class="modal-buttons">
                        <button class="modal-button cancel">${cancelText}</button>
                        <button class="modal-button confirm">${confirmText}</button>
                    </div>
                </div>
            `;

            document.body.appendChild(modal);

            const confirmBtn = modal.querySelector('.confirm');
            const cancelBtn = modal.querySelector('.cancel');
            const input = modal.querySelector('.modal-input');

            const cleanup = () => {
                modal.remove();
            };

            confirmBtn.addEventListener('click', () => {
                cleanup();
                resolve(enableInput ? input?.value : true);
            });

            cancelBtn.addEventListener('click', () => {
                cleanup();
                resolve(null);
            });

            if (input) {
                input.focus();
                input.select();
            }
        });
    }
}

// Loading-Status für Buttons
class ButtonLoader {
    static setLoading(button, isLoading) {
        if (isLoading) {
            button.disabled = true;
            button.dataset.originalText = button.textContent;
            button.classList.add('button-loading');
        } else {
            button.disabled = false;
            button.textContent = button.dataset.originalText;
            button.classList.remove('button-loading');
        }
    }
}

// API-Wrapper mit automatischer Fehlerbehandlung
class ApiService {
    static async fetch(url, options = {}) {
        const button = document.querySelector(`[data-api-target="${url}"]`);
        if (button) {
            ButtonLoader.setLoading(button, true);
        }

        try {
            const response = await fetch(url, options);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            Toast.show('Operation erfolgreich', 'success');
            return data;
        } catch (error) {
            Toast.show(`Fehler: ${error.message}`, 'error');
            throw error;
        } finally {
            if (button) {
                ButtonLoader.setLoading(button, false);
            }
        }
    }
}

// Beispiel für die Verwendung in den bestehenden Funktionen:
async function saveCurrentMesh() {
    if (!isEditing) {
        Toast.show('Bitte zuerst auf "Bearbeiten" klicken', 'error');
        return;
    }

    const confirmed = await ConfirmDialog.show(
        'Möchten Sie die Mesh-Konfiguration wirklich speichern?'
    );

    if (!confirmed) return;

    const meshType = document.getElementById('mesh-select').value;
    const values = {};
    const measuredValues = {};
    
    document.querySelectorAll('#lookup-table tbody tr').forEach((row, index) => {
        values[`runspeed_${index}`] = parseInt(row.querySelector('.runspeed').textContent);
        measuredValues[`measured_${index}`] = parseFloat(row.querySelector('.measured-input').value) || 0;
    });

    try {
        await ApiService.fetch('/save-mesh', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                mesh: meshType,
                values: values,
                measured: measuredValues
            })
        });
        
        toggleEdit();
    } catch (error) {
        console.error('Error saving:', error);
    }
}

// Event Listener für automatische Initialisierung
document.addEventListener('DOMContentLoaded', () => {
    // Toast-Container initialisieren
    Toast.init();
    
    // Globale Fehlerbehandlung
    window.addEventListener('unhandledrejection', (event) => {
        Toast.show(`Unerwarteter Fehler: ${event.reason}`, 'error');
    });
});